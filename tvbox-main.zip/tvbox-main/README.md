# tvbox
自用tvbox源分享，影视仓多仓源分享，tvbox相关资源记录
# 1.影视仓（推荐）
影视仓是一款基于 TVBox 开源代码修改的优秀APP软件，在Tvbox魔改的软件中知名度很高，而且配置方法、直播源等与Tvbox基本一致，除了TV电视盒子外，也同样支持手机APP的使用。

影视仓主要分为三个版本，TV版、游戏版（手机版，内置了街机模拟器）、短视频版（手机版，内置快手短视频），可根据自己的需求选择对应的版本。

优点：

支持多仓源，支持切换源，功能进行了优化


官网：http://qiqiv.cn/

软件分享主页：https://bbs.qiqiv.cn/thread-11997-1-1.html

夸克网盘分享：[https://pan.quark.cn/s/57cfe0fc1079#/list/share](https://pan.quark.cn/s/f57d4c654fb0#/list/share)


# 2.tvbox
仅支持单源，APP内无法方便的切换源

官网地址：http://tvbox.clbug.com/

# 3.源推荐
tip：收集自网络，不保证可用性，需要自己测试，iptv源自己找也行，不过内置的iptv源就够用了，具体看个人


1.https://www.juwanhezi.com/other/jsonlist

# 4.影视仓多仓源接口
1.gitlab（推荐）： https://gitlab.com/noimank/tvbox/-/raw/main/tvboxmuti.json

2.csdn的gitcode： https://raw.gitcode.com/noimank/tvbox/raw/main/tvboxmuti.json

3.GitHub加速：https://gh-proxy.com/https://raw.githubusercontent.com/noimank/tvbox/master/tvboxmuti.json

以上均为本人维护，低调使用

# 5.iptv源

1.https://github.com/HerbertHe/iptv-sources

2.https://github.com/fanmingming/live

3.https://github.com/ssili126/tv

ipv6测试地址：

1：https://test-ipv6.com/

2: https://ipw.cn/

有些直播无法观看有可能是你的网络不支持ipv6，请检查自己的网络环境



